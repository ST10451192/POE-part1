import static org.testng.Assert.*; 

import org.testng.annotations.AfterMethod; 

import org.testng.annotations.BeforeMethod; 

import org.testng.annotations.Test; 

import java.util.ArrayList;

public class continued {
    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package studentmanagementapp;



 

public class StudentManagementAppNGTest { 

 

    @BeforeMethod 

    public void setUpMethod() throws Exception { 

        // Initialize the students list before each test 

        StudentManagementApp.students = new ArrayList<>(); 

    } 

 

    @AfterMethod 

    public void tearDownMethod() throws Exception { 

        // Clear the students list after each test 

        StudentManagementApp.students.clear(); 

    } 

 

    
 

    @Test 

    public void testSearchStudent() { 

        StudentManagementApp.Student student = new StudentManagementApp.Student("10111", "J. Bloggs", 19, "jbloggs@mail.com", "Computer Science"); 

        StudentManagementApp.students.add(student); 

        StudentManagementApp.Student found = StudentManagementApp.findStudentById("10111"); 

        assertNotNull(found); 

        assertEquals("10111", found.getId()); 

    } 

 

    @Test 

    public void testSearchStudent_StudentNotFound() { 

        StudentManagementApp.Student found = StudentManagementApp.findStudentById("99999"); 

        assertNull(found); 

    } 

 

    @Test 

    public void testDeleteStudent() { 

        StudentManagementApp.Student student = new StudentManagementApp.Student("10111", "J. Bloggs", 19, "jbloggs@mail.com", "Computer Science"); 

        StudentManagementApp.students.add(student); 

        StudentManagementApp.students.remove(student); 

        StudentManagementApp.Student found = StudentManagementApp.findStudentById("10111"); 

        assertNull(found); 

    } 

 

    @Test 

    public void testDeleteStudent_StudentNotFound() { 

        StudentManagementApp.Student student = new StudentManagementApp.Student("10111", "J. Bloggs", 19, "jbloggs@mail.com", "Computer Science"); 

        StudentManagementApp.students.add(student); 

        StudentManagementApp.students.remove(student); 

        StudentManagementApp.Student found = StudentManagementApp.findStudentById("99999"); 

        assertNull(found); 

    } 

 

    @Test 

    public void testStudentAge_StudentAgeValid() { 

        StudentManagementApp.Student student = new StudentManagementApp.Student("10111", "J. Bloggs", 19, "jbloggs@mail.com", "Computer Science"); 

        assertTrue(student.isValidAge()); 

    } 

 

    @Test 

    public void testStudentAge_StudentAgeInvalid() { 

        StudentManagementApp.Student student = new StudentManagementApp.Student("10111", "J. Bloggs", 15, "jbloggs@mail.com", "Computer Science"); 

        assertFalse(student.isValidAge()); 

    } 

 

    @Test 

    public void testStudentAge_StudentAgeInvalidCharacter() { 

        boolean thrown = false; 

        try { 

            Integer.parseInt("abc"); 

        } catch (NumberFormatException e) { 

            thrown = true; 

        } 

        assertTrue(thrown); 

    } 

} 

}
