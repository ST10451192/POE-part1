/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */Import java.util.*;
package logistics.manager

   

Public class LogisticsManager { 
    // ArrayLists to store shipments, vehicles, drivers, and maintenance records 
    Private List<Shipment> shipments = new ArrayList<>(); 
    Private List<Vehicle> vehicles = new ArrayList<>(); 
    Private List<Driver> drivers = new ArrayList<>(); 
    Private List<MaintenanceRecord> maintenanceRecords = new ArrayList<>(); 
     
    // Maps for vehicle assignment and shipment status 
    Private Map<Shipment, Vehicle> shipmentAssignments = new HashMap<>(); 
    Private Map<Shipment, String> shipmentStatuses = new HashMap<>(); 
     
    // Main method 
    Public static void main(String[] args) { 
        LogisticsManager manager = new LogisticsManager(); 
        Manager.run(); 
    } 
     
    // Runs the application 
    Public void run() { 
        Scanner scanner = new Scanner(System.in); 
        Int choice; 
        Do { 
            System.out.println(“Logistics Management System”); 
            System.out.println(“1. Add Shipment”); 
            System.out.println(“2. Add Vehicle”); 
            System.out.println(“3. Add Driver”); 
            System.out.println(“4. Assign Shipment to Vehicle”); 
            System.out.println(“5. Schedule Delivery”); 
            System.out.println(“6. Update Shipment Status”); 
            System.out.println(“7. Add Vehicle Maintenance Record”); 
            System.out.println(“8. Check Driver Availability”); 
            System.out.println(“9. Generate Report”); 
            System.out.println(“10. Exit”); 
            System.out.print(“Enter your choice: “); 
            Choice = scanner.nextInt(); 
            Scanner.nextLine();  // Consume newline 
             
            Switch (choice) { 
                Case 1: addShipment(scanner); break; 
                Case 2: addVehicle(scanner); break; 
                Case 3: addDriver(scanner); break; 
                Case 4: assignShipmentToVehicle(scanner); break; 
                Case 5: scheduleDelivery(scanner); break; 
                Case 6: updateShipmentStatus(scanner); break; 
                Case 7: addVehicleMaintenanceRecord(scanner); break; 
                Case 8: checkDriverAvailability(scanner); break; 
                Case 9: generateReport(); break; 
                Case 10: System.out.println(“Exiting...”); break; 
                Default: System.out.println(“Invalid choice. Please try again.”); 
            } 
        } while (choice != 10); 
    } 
     
    // Adds a shipment 
    Private void addShipment(Scanner scanner) { 
        System.out.print(“Enter shipment type (Standard/Express): “); 
        String type = scanner.nextLine(); 
        System.out.print(“Enter origin: “); 
        String origin = scanner.nextLine(); 
        System.out.print(“Enter destination: “); 
        String destination = scanner.nextLine(); 
        Shipment shipment = type.equalsIgnoreCase(“Express”) ? new 
ExpressShipment(origin, destination) : new StandardShipment(origin, destination); 
        Shipments.add(shipment); 
        System.out.println(“Shipment added.”); 
    } 
     
    // Adds a vehicle 
    Private void addVehicle(Scanner scanner) { 
        System.out.print(“Enter vehicle type (Truck/Van): “); 
        String type = scanner.nextLine(); 
        System.out.print(“Enter vehicle ID: “); 
        String id = scanner.nextLine(); 
        Vehicle vehicle = type.equalsIgnoreCase(“Truck”) ? new Truck(id) : new Van(id); 
        Vehicles.add(vehicle); 
        System.out.println(“Vehicle added.”); 
    } 
     
    // Adds a driver 
    Private void addDriver(Scanner scanner) { 
        System.out.print(“Enter driver name: “); 
        String name = scanner.nextLine(); 
        System.out.print(“Enter driver ID: “); 
        String id = scanner.nextLine(); 
        Drivers.add(new Driver(name, id)); 
        System.out.println(“Driver added.”); 
    } 
     
    // Assigns a shipment to a vehicle 
    Private void assignShipmentToVehicle(Scanner scanner) { 
        System.out.print(“Enter shipment origin: “); 
        String origin = scanner.nextLine(); 
        Shipment shipment = findShipmentByOrigin(origin); 
        If (shipment == null) { 
            System.out.println(“Shipment not found.”); 
            Return; 
        } 
        System.out.print(“Enter vehicle ID: “); 
        String vehicleId = scanner.nextLine(); 
        Vehicle vehicle = findVehicleById(vehicleId); 
        If (vehicle == null) { 
            System.out.println(“Vehicle not found.”); 
            Return; 
        } 
        shipmentAssignments.put(shipment, vehicle); 
        System.out.println(“Shipment assigned to vehicle.”); 
    } 
     
    // Schedules a delivery for a shipment 
    Private void scheduleDelivery(Scanner scanner) { 
        System.out.print(“Enter shipment origin: “); 
        String origin = scanner.nextLine(); 
        Shipment shipment = findShipmentByOrigin(origin); 
        If (shipment == null) { 
            System.out.println(“Shipment not found.”); 
            Return; 
        } 
        System.out.print(“Enter delivery date (yyyy-mm-dd): “); 
        String date = scanner.nextLine(); 
        shipmentStatuses.put(shipment, “Scheduled for “ + date); 
        System.out.println(“Delivery scheduled.”); 
    } 
     
    // Updates the status of a shipment 
    Private void updateShipmentStatus(Scanner scanner) { 
        System.out.print(“Enter shipment origin: “); 
        String origin = scanner.nextLine(); 
        Shipment shipment = findShipmentByOrigin(origin); 
        If (shipment == null) { 
            System.out.println(“Shipment not found.”); 
            Return; 
        } 
        System.out.print(“Enter new status: “); 
        String status = scanner.nextLine(); 
        shipmentStatuses.put(shipment, status); 
        System.out.println(“Shipment status updated.”); 
    } 
     
    // Adds a vehicle maintenance record 
    Private void addVehicleMaintenanceRecord(Scanner scanner) { 
        System.out.print(“Enter vehicle ID: “); 
        String id = scanner.nextLine(); 
        Vehicle vehicle = findVehicleById(id); 
        If (vehicle == null) { 
            System.out.println(“Vehicle not found.”); 
            Return; 
        } 
        System.out.print(“Enter maintenance details: “); 
        String details = scanner.nextLine(); 
        maintenanceRecords.add(new MaintenanceRecord(vehicle, details)); 
        System.out.println(“Maintenance record added.”); 
    } 
     
    // Checks if a driver is available 
    Private void checkDriverAvailability(Scanner scanner) { 
        System.out.print(“Enter driver ID: “); 
        String id = scanner.nextLine(); 
        Driver driver = findDriverById(id); 
        If (driver == null) { 
            System.out.println(“Driver not found.”); 
            Return; 
        } 
        System.out.println(“Driver “ + id + “ is available.”); 
    } 
     
    // Generates a report 
    Private void generateReport() { 
        System.out.println(“Shipments:”); 
        For (Shipment shipment : shipments) { 
            System.out.println(shipment); 
            If (shipmentAssignments.containsKey(shipment)) { 
                System.out.println(“  Assigned Vehicle: “ + shipmentAssignments.get(shipment)); 
            } 
            If (shipmentStatuses.containsKey(shipment)) { 
                System.out.println(“  Status: “ + shipmentStatuses.get(shipment)); 
            } 
        } 
        System.out.println(“Vehicles:”); 
        For (Vehicle vehicle : vehicles) { 
            System.out.println(vehicle); 
        } 
        System.out.println(“Drivers:”); 
        For (Driver driver : drivers) { 
            System.out.println(driver); 
        } 
        System.out.println(“Maintenance Records:”); 
        For (MaintenanceRecord record : maintenanceRecords) { 
            System.out.println(record); 
        } 
    } 
     
    // Finds a shipment by origin 
    Private Shipment findShipmentByOrigin(String origin) { 
        For (Shipment shipment : shipments) { 
            If (shipment.getOrigin().equalsIgnoreCase(origin)) { 
                Return shipment; 
            } 
        } 
        Return null; 
    } 
     
    // Finds a vehicle by ID 
    Private Vehicle findVehicleById(String id) { 
        For (Vehicle vehicle : vehicles) { 
            If (vehicle.getId().equalsIgnoreCase(id)) { 
                Return vehicle; 
            } 
        } 
        Return null; 
    } 
     
    // Finds a driver by ID 
    Private Driver findDriverById(String id) { 
        For (Driver driver : drivers) { 
            If (driver.getId().equalsIgnoreCase(id)) { 
                Return driver; 
            } 
        } 
        Return null; 
    } 
} 
 
// Abstract classes and subclasses remain unchanged 
 
Abstract class Shipment { 
    Private String origin; 
    Private String destination; 
     
    Public Shipment(String origin, String destination) { 
        This.origin = origin; 
        This.destination = destination; 
    } 
     
    Public String getOrigin() { 
        Return origin; 
    } 
     
    @Override 
    Public String toString() { 
        Return getClass().getSimpleName() + “ [Origin=” + origin + “, Destination=” + 
destination + “]”; 
    } 
} 
 
Class StandardShipment extends Shipment { 
    Public StandardShipment(String origin, String destination) { 
        Super(origin, destination); 
    } 
} 
 
Class ExpressShipment extends Shipment { 
    Public ExpressShipment(String origin, String destination) { 
        Super(origin, destination); 
    } 
} 
 
Abstract class Vehicle { 
    Private String id; 
     
    Public Vehicle(String id) { 
        This.id = id; 
    } 
     
    Public String getId() { 
        Return id; 
    } 
     
    @Override 
    Public String toString() { 
        Return getClass().getSimpleName() + “ [ID=” + id + “]”; 
    } 
} 
 
Class Truck extends Vehicle { 
    Public Truck(String id) { 
        Super(id); 
    } 
} 
 
Class Van extends Vehicle { 
    Public Van(String id) { 
        Super(id); 
    } 
} 
 
Class Driver { 
    Private String name; 
    Private String id; 
     
    Public Driver(String name, String id) { 
        This.name = name; 
        This.id = id; 
    } 
     
    Public String getId() { 
        Return id; 
    } 
     
    @Override 
    Public String toString() { 
        Return “Driver [Name=” + name + “, ID=” + id + “]”; 
    } 
} 
 
Class MaintenanceRecord { 
    Private Vehicle vehicle; 
    Private String details; 
     
    Public MaintenanceRecord(Vehicle vehicle, String details) { 
        This.vehicle = vehicle; 
This.details = details; 
} 
@Override 
Public String toString() { 
Return “Maintenance Record [Vehicle=” + vehicle + “, Details=” + det
        
    }
    
}
}
